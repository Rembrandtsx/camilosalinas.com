# Bogeyman theme for Ghost blogging

The theme is developed on top of default [Ghost](http://github.com/tryghost/ghost/) theme which is [Casper](https://github.com/TryGhost/Casper) and [Attila](https://github.com/zutrinken/attila). You can see the [demo](http://blog.ambitionbox.com).

&nbsp;

## screenshots

### 1. Landing page
The posts are grouped by their primary tag (first tag), Showing the count and see more link which will take the user to the tag page

![screenshot-desktop](https://raw.githubusercontent.com/subramanya92/Ambitionbox-Blog-theme/master/Screenshot.png)

### 2. Post page
The disqus comments are enabled by default, you could comment out the code. Just replace with your embed code from disqus.

![screenshot-desktop](https://raw.githubusercontent.com/subramanya92/Ambitionbox-Blog-theme/master/sample-post-screenshot.png)

![screenshot-desktop](https://raw.githubusercontent.com/subramanya92/Ambitionbox-Blog-theme/master/post_bottom_screenshot.png)



**The main files are:**

- `default.hbs` - The main template file
- `index.hbs` - Used for the home page
- `post.hbs` - Used for individual posts
- `page.hbs` - Used for individual pages
- `tag.hbs` - Used for tag archives
- `author.hbs` - Used for author archives

One really neat trick is that you can also create custom one-off templates just by adding the slug of a page to a template file. For example:

- `page-about.hbs` - Custom template for the `/about/` page
- `tag-news.hbs` - Custom template for `/tag/news/` archive
- `author-ali.hbs` - Custom template for `/author/ali/` archive


# Development

Casper styles are compiled using Gulp/PostCSS to polyfill future CSS spec. You'll need Node and Gulp installed globally. After that, from the theme's root directory:

```bash
$ npm install
$ gulp
```

Now you can edit `/assets/css/` files, which will be compiled to `/assets/built/` automatically.

The `zip` Gulp task packages the theme files into `dist/<theme-name>.zip`, which you can then upload to your site.

```bash
$ gulp zip
```

# PostCSS Features Used

- Autoprefixer - Don't worry about writing browser prefixes of any kind, it's all done automatically with support for the latest 2 major versions of every browser.
- Variables - Simple pure CSS variables
- [Color Function](https://github.com/postcss/postcss-color-function)


# SVG Icons

Casper uses inline SVG icons, included via Handlebars partials. You can find all icons inside `/partials/icons`. To use an icon just include the name of the relevant file, eg. To include the SVG icon in `/partials/icons/rss.hbs` - use `{{> "icons/rss"}}`.

You can add your own SVG icons in the same manner.

